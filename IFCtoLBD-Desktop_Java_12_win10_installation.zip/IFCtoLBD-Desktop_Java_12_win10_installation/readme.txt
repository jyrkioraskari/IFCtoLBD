This versio should be fine for the users that use Java 10 or newer. The main difference is in the user interface´
element that needs a separate version to fuction under Java 12 (or newer). 